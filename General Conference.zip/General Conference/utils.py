import re
from collections import Counter
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer

_token_re = re.compile(r"\b\w+\b")

def tokenize_and_count(text, remove_stopwords=True, lemmatize=False):
    text = text.lower()
    tokens = _token_re.findall(text)
    if remove_stopwords:
        try:
            sw = set(stopwords.words('english'))
        except Exception:
            import nltk
            nltk.download('stopwords', quiet=True)
            sw = set(stopwords.words('english'))
        tokens = [t for t in tokens if t not in sw]
    if lemmatize:
        lem = WordNetLemmatizer()
        tokens = [lem.lemmatize(t) for t in tokens]
    return Counter(tokens)
