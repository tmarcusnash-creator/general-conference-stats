General Conference — Word Usage Explorer

Overview
--------
This project provides a Streamlit web app to explore word usage across General Conference talks over time. It includes helper scripts to fetch talks from the Church website and to process local talk files.

Quick start
-----------
1. Create a Python environment (recommended: Python 3.9+).
2. Install dependencies:

```bash
pip install -r requirements.txt
```

3. Prepare data:
- Option A: Upload a CSV with columns `date,title,speaker,text` in the app UI.
- Option B: Place HTML/text files in `data/raw/` and run `python process_text.py` to build `data/talks.csv`.

4. Run the Streamlit app:

```bash
streamlit run app.py
```

Sharing
-------
- Push this folder to a GitHub repo and deploy on Streamlit Cloud for easy sharing.
- Alternatively run on any server and expose via `ngrok` or other tunneling tool.

Notes
-----
- The fetch script (`fetch_gc_talks.py`) uses simple HTML parsing and may need tweaks if the website structure changes.
- The app removes stopwords by default; lemmatization is optional.
General Conference — Word Usage Explorer

Overview
--------
This small project provides a Streamlit web app to explore word usage across General Conference talks over time. It includes helper scripts to fetch talks from the Church website and prepare them for analysis.

Quick start
-----------
1. Create a Python environment (recommended: Python 3.9+).
2. Install dependencies:

```bash
pip install -r requirements.txt
```

3. Fetch talks (crawl an index page or provide a list of talk URLs):

```bash
python fetch_gc_talks.py --index "https://www.churchofjesuschrist.org/study/general-conference?lang=eng"
```

4. Process fetched talks into a usable dataset:

```bash
python process_text.py
```

5. Run the Streamlit app:

```bash
streamlit run app.py
```

Sharing
-------
- Push this folder to a GitHub repo and deploy on Streamlit Cloud for easy sharing (see Streamlit docs).

Notes
-----
- The fetch script uses simple HTML parsing; site structure changes may require small fixes.
- The app computes word counts on-demand — stopwords are removed by default.
