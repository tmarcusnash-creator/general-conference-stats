"""
Basic fetcher for General Conference talk pages.
Usage:
    python fetch_gc_talks.py --index "https://www.churchofjesuschrist.org/study/general-conference?lang=eng"

This script finds links on the index page that look like talk pages and downloads them to data/raw/.
"""
import requests
from bs4 import BeautifulSoup
import os
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('--index', help='Index URL to scan', required=True)
parser.add_argument('--outdir', help='Output directory', default='data/raw')
args = parser.parse_args()

os.makedirs(args.outdir, exist_ok=True)

resp = requests.get(args.index)
resp.raise_for_status()

soup = BeautifulSoup(resp.text, 'html.parser')
links = set()
for a in soup.find_all('a', href=True):
    href = a['href']
    if '/study/general-conference/' in href or '/study/general-conference' in href:
        if href.startswith('http'):
            links.add(href)
        else:
            links.add('https://www.churchofjesuschrist.org' + href)

print(f'Found {len(links)} links; downloading sample of first 50')
for i, link in enumerate(sorted(links)[:50]):
    try:
        r = requests.get(link)
        r.raise_for_status()
        fn = os.path.join(args.outdir, f'talk_{i}.html')
        with open(fn, 'w', encoding='utf-8') as f:
            f.write(r.text)
        print('Saved', fn)
    except Exception as e:
        print('Failed', link, e)
