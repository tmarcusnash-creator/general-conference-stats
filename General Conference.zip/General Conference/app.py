import streamlit as st
import pandas as pd
import altair as alt
import os
from utils import tokenize_and_count
import nltk

try:
    nltk.data.find('tokenizers/punkt')
except Exception:
    nltk.download('punkt', quiet=True)
try:
    nltk.data.find('corpora/stopwords')
except Exception:
    nltk.download('stopwords', quiet=True)
try:
    nltk.data.find('corpora/wordnet')
except Exception:
    nltk.download('wordnet', quiet=True)

st.set_page_config(layout="wide", page_title="General Conference Word Explorer")
st.title("General Conference — Word Usage Explorer")

st.sidebar.header("Data")
upload = st.sidebar.file_uploader("Upload talks CSV (date,title,speaker,text)", type=["csv"]) 
use_sample = False
if upload is None:
    default_path = os.path.join('data', 'talks.csv')
    if os.path.exists(default_path):
        df = pd.read_csv(default_path, parse_dates=['date'])
    else:
        # load example bundled dataset
        df = pd.read_csv(os.path.join('data', 'example_talks.csv'), parse_dates=['date'])
        use_sample = True
else:
    df = pd.read_csv(upload, parse_dates=['date'])

st.sidebar.header("Options")
remove_stopwords = st.sidebar.checkbox("Remove stopwords", value=True)
lemmatize = st.sidebar.checkbox("Lemmatize words", value=False)
normalize = st.sidebar.selectbox("Normalize counts", ["Raw counts", "Per 1000 words"])
smooth = st.sidebar.slider("Smoothing window (talks)", 1, 9, 1)

st.sidebar.markdown("---")
st.sidebar.markdown("Data rows: {}".format(len(df)))

st.markdown("### Data preview")
st.dataframe(df[['date','title','speaker']].head())

query = st.text_input("Enter words (comma-separated)", value="faith, hope")
words = [w.strip().lower() for w in query.split(',') if w.strip()]

if not words:
    st.info('Enter one or more words to analyze')
    st.stop()

# compute counts
counts = {}
for w in words:
    counts[w] = []

for _, row in df.iterrows():
    text = str(row.get('text',''))
    tokens = tokenize_and_count(text, remove_stopwords=remove_stopwords, lemmatize=lemmatize)
    total_words = sum(tokens.values())
    for w in words:
        counts[w].append(tokens.get(w,0))

plot_df = pd.DataFrame({'date': df['date']})
for w in words:
    ser = pd.Series(counts[w])
    if normalize == 'Per 1000 words':
        total = []
        for _, row in df.iterrows():
            total_words = sum(tokenize_and_count(str(row.get('text','')), remove_stopwords=remove_stopwords, lemmatize=lemmatize).values())
            total.append(total_words if total_words>0 else 1)
        ser = ser / (pd.Series(total) / 1000.0)
    plot_df[w] = ser

# group by date (if multiple talks share same date)
plot_df = plot_df.groupby('date').sum().sort_index()
if smooth > 1:
    plot_df = plot_df.rolling(smooth, min_periods=1).mean()

st.markdown("### Frequency over time")
chart_df = plot_df.reset_index().melt('date', var_name='word', value_name='count')
chart = alt.Chart(chart_df).mark_line(point=True).encode(
    x='date:T',
    y='count:Q',
    color='word:N',
    tooltip=['date','word','count']
).interactive()
st.altair_chart(chart, use_container_width=True)

st.markdown("### Table")
st.dataframe(plot_df.tail(50))

if use_sample:
    st.info('You are viewing the bundled example dataset. Upload your talks CSV or place processed `talks.csv` in the data/ folder.')
