"""
Generate a standalone static HTML viewer `static_viewer.html` from `data/talks.csv`.
It embeds precomputed per-date token counts (top N tokens) and a small JS UI to enter words and plot their frequency over time.

Usage:
    python export_static.py --top 500

"""
import pandas as pd
import argparse
import json
from collections import Counter, defaultdict
from utils import tokenize_and_count

parser = argparse.ArgumentParser()
parser.add_argument('--input', default='data/talks.csv')
parser.add_argument('--out', default='static_viewer.html')
parser.add_argument('--top', type=int, default=500, help='Top N tokens to include')
args = parser.parse_args()

df = pd.read_csv(args.input, parse_dates=['date'])
# group by date
bydate = defaultdict(Counter)
for _, row in df.iterrows():
    date = pd.to_datetime(row['date']).strftime('%Y-%m-%d') if pd.notna(row['date']) else 'unknown'
    tokens = tokenize_and_count(str(row.get('text','')), remove_stopwords=True, lemmatize=False)
    bydate[date].update(tokens)

# get top tokens overall
overall = Counter()
for d,c in bydate.items():
    overall.update(c)
most = [w for w,_ in overall.most_common(args.top)]

dates = sorted(bydate.keys())
data = {'dates': dates, 'tokens': {}}
for w in most:
    data['tokens'][w] = [bydate[d].get(w,0) for d in dates]

# write html
html_template = '''<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>General Conference — Word Usage (static)</title>
  <style>
    body{font-family:Arial,Helvetica,sans-serif;margin:20px}
    #chart{width:100%;height:500px}
  </style>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
  <h2>General Conference — Word Usage (static)</h2>
  <p>Enter comma-separated words to plot (stopwords removed during export).</p>
  <input id="words" style="width:60%" value="faith, hope"/>
  <button id="go">Plot</button>
  <div>
    <canvas id="chart"></canvas>
  </div>
<script>
const DATA = __DATA__;
const dates = DATA.dates;
const tokens = DATA.tokens;
function plot(words){
  const ctx = document.getElementById('chart').getContext('2d');
  if(window._chart) window._chart.destroy();
  const datasets = words.map((w,idx)=>({
    label: w,
    data: tokens[w] ? tokens[w] : dates.map(()=>0),
    fill: false,
    borderColor: ['#1f77b4','#ff7f0e','#2ca02c','#d62728','#9467bd','#8c564b'][idx%6]
  }));
  window._chart = new Chart(ctx, {
    type: 'line',
    data: {labels: dates, datasets: datasets},
    options: {responsive:true, interaction:{mode:'index',intersect:false}, stacked:false}
  });
}

document.getElementById('go').addEventListener('click',()=>{
  const raw = document.getElementById('words').value;
  const words = raw.split(',').map(x=>x.trim().toLowerCase()).filter(x=>x);
  plot(words);
});
// initial plot
plot(['faith','hope']);
</script>
</body>
</html>
'''

with open(args.out, 'w', encoding='utf-8') as f:
    f.write(html_template.replace('__DATA__', json.dumps(data)))
print('Wrote', args.out)
