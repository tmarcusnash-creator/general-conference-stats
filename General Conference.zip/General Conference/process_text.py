"""
Process files in data/raw/ (HTML or txt) and extract `date,title,speaker,text` into `data/talks.csv`.
"""
import os
from bs4 import BeautifulSoup
import pandas as pd
import glob

in_dir = 'data/raw'
out_csv = 'data/talks.csv'
os.makedirs('data', exist_ok=True)

rows = []
for path in sorted(glob.glob(os.path.join(in_dir, '*'))):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            html = f.read()
        soup = BeautifulSoup(html, 'html.parser')
        text = soup.get_text(separator=' ', strip=True)
        title_tag = soup.find('h1')
        title = title_tag.get_text(strip=True) if title_tag else os.path.basename(path)
        # try meta date
        date = None
        meta = soup.find('meta', {'property':'article:published_time'})
        if meta and meta.get('content'):
            date = meta['content']
        rows.append({'date': date or '', 'title': title, 'speaker': '', 'text': text})
    except Exception as e:
        print('err', path, e)

if rows:
    df = pd.DataFrame(rows)
    # try to coerce dates where present
    try:
        df['date'] = pd.to_datetime(df['date'], errors='coerce')
    except Exception:
        pass
    df.to_csv(out_csv, index=False)
    print('Wrote', out_csv)
else:
    print('No files processed from', in_dir)
